// orders.js

document.addEventListener('DOMContentLoaded', () => {
    fetch('data/menu-items.json')
        .then(response => response.json())
        .then(data => {
            const menuItems = data.items;
            const itemNameInput = document.getElementById('item-name');
            const quantityInput = document.getElementById('quantity');
            const orderItemsList = document.getElementById('order-items');
            const totalPriceElement = document.getElementById('total-price');
            const completeOrderButton = document.getElementById('complete-order');

            let orderItems = [];
            let totalPrice = 0;

            document.getElementById('order-form').addEventListener('submit', (event) => {
                event.preventDefault();
                const itemName = itemNameInput.value;
                const quantity = parseInt(quantityInput.value);

                const item = menuItems.find(i => i.name.toLowerCase() === itemName.toLowerCase());
                if (item) {
                    const itemTotalPrice = parseFloat(item.price) * quantity;
                    orderItems.push({ name: item.name, quantity, price: itemTotalPrice });
                    totalPrice += itemTotalPrice;

                    const listItem = document.createElement('li');
                    listItem.textContent = `${item.name} x${quantity} - ${item.price} each`;
                    orderItemsList.appendChild(listItem);

                    totalPriceElement.textContent = `Total Price: ${totalPrice.toFixed(2)}`;

                    // Clear form inputs
                    itemNameInput.value = '';
                    quantityInput.value = '';
                } else {
                    alert('Item not found');
                }
            });

            completeOrderButton.addEventListener('click', () => {
                if (orderItems.length > 0) {
                    // Handle order completion (mock)
                    console.log('Order completed:', orderItems, 'Total Price:', totalPrice);
                    alert('Order completed successfully!');
                    orderItems = [];
                    totalPrice = 0;
                    orderItemsList.innerHTML = '';
                    totalPriceElement.textContent = 'Total Price: 0';
                } else {
                    alert('No items in order');
                }
            });
        });
});
